import pygame

def init(obj):
    obj["x"] = obj.get("x", 100)
    obj["y"] = obj.get("y", 100)
    obj["speed"] = obj.get("speed", 3)

def update(obj, screen):
    if "speed" not in obj:
        obj["speed"] = 3  # valor por defecto

    keys = pygame.key.get_pressed()

    if keys[pygame.K_LEFT]:
        obj["x"] -= obj["speed"]
    if keys[pygame.K_RIGHT]:
        obj["x"] += obj["speed"]
    if keys[pygame.K_UP]:
        obj["y"] -= obj["speed"]
    if keys[pygame.K_DOWN]:
        obj["y"] += obj["speed"]


    for event in keys:
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                print(f"[{obj['name']}] ¡Espacio presionado!")